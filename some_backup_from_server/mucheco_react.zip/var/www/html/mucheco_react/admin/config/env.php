<?php
$APP_ENV='live';

$APP_URL="http://88.208.224.110/mucheco_react/admin/";

$TEST_URL="http://localhost/mucheco_react/admin/";