<?php
header($_SERVER["SERVER_PROTOCOL"] . " 400 Not Found", true, 400);
exit;